# myfacts
Facter for InfraOps.
##Custom Facts
- [1 Datacenter fact]
- [1 Environment fact]
- [1 NTP Configuration fact]
- [1 Server Role fact]
- [1 Solution ID fact]
